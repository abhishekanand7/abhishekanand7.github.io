from setuptools import setup, find_packages
setup(
    name = 'sis_pipeline',
    packages = find_packages(),
)